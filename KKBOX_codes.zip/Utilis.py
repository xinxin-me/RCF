from time import time

def get_relational_data(user_id, item_id, data):  # given a user-item pair, return the relational data
    # user, positive, negative, alpha = [], [], [], []
    r0, r1, r2, r3,r4 = [], [], [], [],[]                                     #the item set in ru+ which has relationship r0,r1,r2,r3 with i
    # cnt0, cnt1, cnt2, cnt3 = [], [], [], []                           # the number of corresponding r, for masking
    e1, e2, e3,e4 = [], [], [],[]                                             # the set of specific attribute value for correspoding r except r0
    # get sample
    pos = data.user_positive_list[user_id]
    id1 = data.items_traverse[item_id]
    song1 = data.song_dict[id1]
    ru_list = list(pos)
    if item_id in ru_list:
        ru_list.remove(item_id)

    for another_item in ru_list:
        id2 = data.items_traverse[another_item]
        song2 = data.song_dict[id2]
        shared_genre, shared_artist, shared_composer, shared_lyrist=get_share_attributes(song1, song2)
        #shared_genre, shared_director, shared_actor = get_share_attributes(movie1, movie2)
        if len(shared_genre) + len(shared_artist) + len(shared_composer)+len(shared_lyrist) == 0:
            r0.append(another_item)
        if len(shared_genre) != 0:
            for value in shared_genre:
                r1.append(another_item)
                e1.append(value)
        if len(shared_artist) != 0:
            for value in shared_artist:
                r2.append(another_item)
                e2.append(value)
        if len(shared_composer) != 0:
            for value in shared_composer:
                r3.append(another_item)
                e3.append(value)
        if len(shared_lyrist) != 0:
            for value in shared_lyrist:
                r4.append(another_item)
                e4.append(value)
    cnt0=len(r0)
    cnt1=len(r1)
    cnt2=len(r2)
    cnt3=len(r3)
    cnt4=len(r4)
    return r0,r1,r2,r3,r4,e1,e2,e3,e4,cnt0,cnt1,cnt2,cnt3,cnt4


def get_share_attributes(song1, song2):
    genre_list1 = song1.genre
    genre_list2 = song2.genre
    len1,len2=len(genre_list1), len(genre_list2)
    if len1==1 and len2==1:
        if genre_list1[0]==genre_list2[0]:
            shared_genre=genre_list1
        else:
            shared_genre=[]
    if len1==1 and len2!=1:
        if genre_list1[0] in genre_list2:
            shared_genre=genre_list1
        else:
            shared_genre=[]
    if len1!=1 and len2==1:
        if genre_list2[0] in genre_list1:
            shared_genre=genre_list2
        else:
            shared_genre=[]
    if len1!=1 and len2!=1:
        shared_genre = filter(set(genre_list1).__contains__, genre_list2)
    #shared_genre = list(set(genre_list1) & set(genre_list2))
    artist1=song1.artist
    artist2=song2.artist
    if artist1==artist2:
        shared_artist=[artist1]
    else:
        shared_artist=[]

    composer1 = song1.composer
    composer2 = song2.composer
    if composer1==composer2:
        shared_composer=[composer1]
    else:
        shared_composer=[]

    lyrist1 = song1.lyrist
    lyrist2 = song2.lyrist
    if lyrist1 == lyrist2:
        shared_lyrist = [lyrist1]
    else:
        shared_lyrist = []

    return shared_genre, shared_artist,shared_composer,shared_lyrist