import argparse

class song:
    def __init__(self, genre, artist,composer, lyrist):
        self.genre = genre
        self.artist=artist
        self.composer=composer
        self.lyrist=lyrist


class song_loader:
    def __init__(self):
        self.song_dict=self.load_song()
        self.genre_list, self.artist_list, self.composer_lisr, self.lyrist_list=self.load_attribute()


    def load_song(self):  # map the feature entries in all files, kept in self.features dictionary
        parser = argparse.ArgumentParser(description=''' load movie data''')

        parser.add_argument('--song_data_file', type=str, default='./KKBox/auxiliary-mapping.txt')

        parsed_args = parser.parse_args()

        song_file = parsed_args.song_data_file
        song_dict= {}

        fr = open(song_file, 'r')
        for line in fr:
            lines = line.replace('\n', '').split('|')
            # if len(lines) != 4:
            #     continue
            song_id = lines[0]
            genre_list = []
            genres = lines[1].split(',')
            for item in genres:
                genre_list.append(int(item))
            artist=int(lines[2])
            composer=int(lines[3])
            lyrist=int(lines[4])
            new_song= song(genre_list, artist,composer, lyrist)
            song_dict[song_id]=new_song
        fr.close()
        return song_dict

    def load_attribute(self):  # map the feature entries in all files, kept in self.features dictionary
        parser = argparse.ArgumentParser(description=''' load movie data''')

        parser.add_argument('--song_data_file', type=str, default='./KKBox/auxiliary-mapping.txt')

        parsed_args = parser.parse_args()

        song_file = parsed_args.song_data_file
        genre_list = []
        artist_list=[]
        composer_list=[]
        lyrist_list=[]
        fr = open(song_file, 'r')
        for line in fr:
            lines = line.replace('\n', '').split('|')
            # if len(lines) != 4:
            #     continue
            genres = lines[1].split(',')
            for item in genres:
                if int(item) not in genre_list:
                    genre_list.append(int(item))
            artist = lines[2]
            if int(artist) not in artist_list:
                artist_list.append(int(artist))
            composer = lines[3]
            if int(composer) not in composer_list:
                composer_list.append(int(composer))
            lyrist = lines[4]
            if int(lyrist) not in lyrist_list:
                lyrist_list.append(int(lyrist))

        fr.close()
        return genre_list,artist_list,composer_list,lyrist_list